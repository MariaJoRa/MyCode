package tallerArreglos;

import java.util.Arrays;

import javax.swing.JOptionPane;

public class Punto5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String[] productos = {"Chocolate", "galletas", "gomitas"};
		int[] precios = {2000, 3000, 4000};
		
		String menu= JOptionPane.showInputDialog("Menu:\n"
				+"1. Productos y precios\n"
				+"2. Vender un producto\n"
				+"3. Total de ingresos\n"
				+"4. Cambiar precio");
		int menuInt = Integer.parseInt(menu);
		switch(menuInt) {
		
		case 1:
			System.out.println("Productos:"+Arrays.toString(productos));
			System.out.print("Precios:  "+Arrays.toString(precios)+"  ");
		
		case 2:
			String venta = JOptionPane.showInputDialog("Ingrese el número del producto que desea vender: \n"
					+"1. Chocolate\n"
					+"2. Galletas\n"
					+"3. Gomitas\n");
			int ventaInt = Integer.parseInt(venta);
			
		switch(ventaInt) {
		case 1:
			String cantidad= JOptionPane.showInputDialog("Ingrese la cantidad del producto a vender:");
			int cantidadInt = Integer.parseInt(cantidad);
			int valorCompra= cantidadInt*2000;
			System.out.print("El valor de la compra es: "+ valorCompra);
			break;
		case 2:
			String cantidad2= JOptionPane.showInputDialog("Ingrese la cantidad del producto a vender: ");
			int cantidad2Int= Integer.parseInt(cantidad2);
			int valorCompra2= cantidad2Int*3000;
			System.out.print("El valor de la compra es: "+valorCompra2);
			break;
		case 3:
			String cantidad3= JOptionPane.showInputDialog("Ingrese la cantidad del producto a vender: ");
			int cantidad3Int=Integer.parseInt(cantidad3);
			int valorCompra3= cantidad3Int*4000;
			System.out.print("El valor de la compra es: "+ valorCompra3);
			break;
		}
		case 3:
			
			
		}
	}

}
