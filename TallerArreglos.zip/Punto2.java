package tallerArreglos;

public class Punto2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       
		
		//Definir el rango de los números aleatorios
		int min= 0;
		int max= 20;
		
		int [] numerosAleatorios= new int[6];
		
		for(int i=0; i< numerosAleatorios.length; i++) {
			int valorAleatorio= (int) Math.floor(Math.random()*(max-min+1))+ min;
			numerosAleatorios[i]= valorAleatorio;
			
			if(numerosAleatorios[i]%3==0) {
				System.out.println("El número "+ numerosAleatorios[i]+" es múltiplo de 3");
			}
		}
		for(int valor: numerosAleatorios) {
			System.out.println("Número: "+ valor);
		}
	}

}
