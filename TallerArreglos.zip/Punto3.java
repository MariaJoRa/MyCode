package tallerArreglos;

import java.util.Arrays;

public class Punto3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int max= 9;
		int min= 1;
		
		int[] numerosAleatorios= new int[10];
		
		for(int i=0; i<10; i++) {
			int valorAleatorio = (int) Math.floor(Math.random()*(max-min+1))+min;
				numerosAleatorios[i]=valorAleatorio;
				System.out.print(valorAleatorio+ " ");
		}
		Arrays.sort(numerosAleatorios);
		System.out.println( "\nNúmeros ordenados de menor a mayor: "+Arrays.toString(numerosAleatorios));
	}

}
