package tallerArreglos;

public class Punto4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int min= 0;
		int max= 1;
		int[] numeros = new int[20];
		int contador=0;
		
		for(int i=0; i<numeros.length; i++) {
			int valorAleatorio= (int) Math.floor(Math.random()*(max-min+1))+min;
		    numeros[i]= valorAleatorio;		
		    System.out.print(numeros[i]+" "); 
		    if(valorAleatorio==0) {
		    	contador++;
		    }
		    }System.out.println("\nCantidad de valores iguales a cero: "+contador);
		} 
	}


