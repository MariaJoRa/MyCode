package tallerArreglos;

import javax.swing.JOptionPane;

public class Punto1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] numeros= new int [4];
		
		for(int i=0; i<numeros.length; i++) {
			numeros[i]= Integer.parseInt(JOptionPane.showInputDialog("Por favor ingrese un número: "));
		
		}
		int mayor= numeros[0];
		int menor= numeros[3];
		for(int x=0; x<numeros.length; x++) {
			if(numeros[x]> mayor) {
				mayor= numeros[x];
			}
			if(numeros[x]< menor) {
				menor= numeros[x];
			}
		}
		System.out.println("EL número menor es: "+ menor+" y el número mayor es: "+mayor);
		}
		
	

}
