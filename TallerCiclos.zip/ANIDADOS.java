package tallerCiclos;

public class ANIDADOS {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int i = 0;

		do {
		int j=0; 
		do {
		  System.out.println(i);
		  j++;
		}while (j < 2);

		i++;
		}while (i < 5);

	}

}
