package tallerCiclos;

import javax.swing.JOptionPane;

public class Anidados3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/*for(int i=5; i>0; i--) {
		System.out.println(i);
	}
	System.out.print("¡Feliz año!");
	}*/
		String num= JOptionPane.showInputDialog("Ingrese un número: ");
		int numInt= Integer.parseInt(num);
		 
		for(int i=1;i<=numInt;i++){  
		for(int j=i;j<=numInt;j++){  
		        System.out.print(j);  
		}  
		System.out.println();
		
		

		}
}
}
