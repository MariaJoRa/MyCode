package tallerCiclos;

import javax.swing.JOptionPane;

public class Anidados4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String n = JOptionPane.showInputDialog("Ingrese un número ");
		int nInt = Integer.parseInt(n);
		
		for(int i=1,p=nInt; i<=nInt; i++,p--) {
			for(int j=1;j<=i;j++) {
				System.out.print(p+" ");
			}
			System.out.println();
		}
	}

}
