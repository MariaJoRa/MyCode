package tallerCiclos;

import javax.swing.JOptionPane;

public class Anidados2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	String num= JOptionPane.showInputDialog("Ingrese un número: ");
	int numInt= Integer.parseInt(num);
	
	for(int i=1; i<= numInt ; i++) {
		for(int j=1; j<=i;j++) {
			System.out.print(j);
		}
		System.out.println();
	}
	}

}
